<?php
    session_start();
    $_SESSION["nome"] = "Maria";
    
    echo "Criada variável de sessão";
